<?php 
    //config.php

    //CONNECTION 
    $host = 'XXXXX'; // hostname
    $username = 'XXXXX';//username 
    $pass = 'XXXX'; //password 
    $dbname = 'XXXX'; // Database Name

    $mysqli = new mysqli($host, $username, $pass, $dbname);
 
  

 ?>